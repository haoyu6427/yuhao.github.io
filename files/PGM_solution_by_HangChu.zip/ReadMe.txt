This solution is provided by Hang Chu. Not all problems are solved optimally, but they can pass the test successfully.

Only for academic sharing & communicating, do not distribute.

Contact: chuhang1122@gmail.com